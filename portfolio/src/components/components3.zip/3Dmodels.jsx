
import React, { useState, useEffect } from 'react';
import '../styles/3Dmodels.css';

const ThreeDModelsSection = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Updated mobile models data - just images for mobile
  const mobileModels = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=400&auto=format&fit=crop",
      title: "Geometric Sculpture"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&auto=format&fit=crop",
      title: "Organic Creature"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=400&auto=format&fit=crop",
      title: "Future Vehicle"
    },
    {
      id: 4,
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&auto=format&fit=crop",
      title: "Abstract Composition"
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=400&auto=format&fit=crop",
      title: "Mechanical Assembly"
    },
    {
      id: 6,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&auto=format&fit=crop",
      title: "Architectural Model"
    },
    {
      id: 7,
      image: "https://images.unsplash.com/photo-1577032229840-33197764440d?w=400&auto=format&fit=crop",
      title: "Product Design"
    },
    {
      id: 8,
      image: "https://images.unsplash.com/photo-1535223289827-42f1e9919769?w=400&auto=format&fit=crop",
      title: "Character Model"
    }
  ];

  // Original desktop models (unchanged)
  const desktopModels = [
    {
      id: 1,
      title: "Geometric Sculpture",
      category: "Architecture",
      description: "Modern geometric sculpture with clean lines and dynamic form.",
      year: "2024",
      software: ["Blender"],
      polyCount: "25k",
      bgColor: "#6366F1",
      previewColor: "#818CF8",
      rotationSpeed: 0.01,
      defaultDistance: 10,
      minDistance: 3,
      maxDistance: 10,
      modelPath: "/models/model2.glb",
      modelFileName: "geometric_sculpture.glb"
    },
    {
      id: 2,
      title: "Organic Creature",
      category: "Character Design",
      description: "Fantasy creature with organic forms and detailed textures.",
      year: "2024",
      software: ["Blender"],
      polyCount: "50k",
      bgColor: "#10B981",
      previewColor: "#34D399",
      rotationSpeed: 0.01,
      defaultDistance: 7,
      minDistance: 3,
      maxDistance: 15,
      modelPath: "/models/model3.glb",
      modelFileName: "organic_creature.glb"
    },
    {
      id: 3,
      title: "Future Vehicle",
      category: "Product Design",
      description: "Concept vehicle for 2050 with aerodynamic curves.",
      year: "2024",
      software: ["Blender"],
      polyCount: "75k",
      bgColor: "#F59E0B",
      previewColor: "#FBBF24",
      rotationSpeed: 0.01,
      defaultDistance: 8,
      minDistance: 5,
      maxDistance: 20,
      modelPath: "/models/model2.glb",
      modelFileName: "future_vehicle.glb"
    },
    {
      id: 4,
      title: "Abstract Composition",
      category: "Art",
      description: "Non-representational composition exploring light and shadow.",
      year: "2023",
      software: ["Blender"],
      polyCount: "15k",
      bgColor: "#8B5CF6",
      previewColor: "#A78BFA",
      rotationSpeed: 0.01,
      defaultDistance: 5,
      minDistance: 3,
      maxDistance: 10,
      modelPath: "/models/model2.glb",
      modelFileName: "abstract_composition.glb"
    },
    {
      id: 5,
      title: "Modular Architecture",
      category: "Architecture",
      description: "Modular building system for sustainable urban environments.",
      year: "2024",
      software: ["Blender"],
      polyCount: "40k",
      bgColor: "#EF4444",
      previewColor: "#F87171",
      rotationSpeed: 0.01,
      defaultDistance: 9,
      minDistance: 6,
      maxDistance: 25,
      modelPath: "/models/model2.glb",
      modelFileName: "modular_architecture.glb"
    },
    {
      id: 6,
      title: "Mechanical Assembly",
      category: "Industrial Design",
      description: "Complex mechanical assembly with moving parts.",
      year: "2023",
      software: ["Blender"],
      polyCount: "100k",
      bgColor: "#06B6D4",
      previewColor: "#22D3EE",
      rotationSpeed: 0.01,
      defaultDistance: 7,
      minDistance: 4,
      maxDistance: 18,
      modelPath: "/models/model2.glb",
      modelFileName: "mechanical_assembly.glb"
    },
    {
      id: 7,
      title: "Strange Flora",
      category: "Environmental",
      description: "Alien plant life designed for a sci-fi environment.",
      year: "2024",
      software: ["Blender"],
      polyCount: "30k",
      bgColor: "#84CC16",
      previewColor: "#A3E635",
      rotationSpeed: 0.01,
      defaultDistance: 6,
      minDistance: 3,
      maxDistance: 12,
      modelPath: "/models/model2.glb",
      modelFileName: "strange_flora.glb"
    },
    {
      id: 8,
      title: "Jewelry Collection",
      category: "Jewelry Design",
      description: "High-end jewelry with intricate patterns and gems.",
      year: "2023",
      software: ["Blender"],
      polyCount: "10k",
      bgColor: "#EC4899",
      previewColor: "#F472B6",
      rotationSpeed: 0.01,
      defaultDistance: 4,
      minDistance: 2,
      maxDistance: 8,
      modelPath: "/models/model2.glb",
      modelFileName: "jewelry_collection.glb"
    },
    {
      id: 9,
      title: "Ancient Artifact",
      category: "Archaeology",
      description: "Recreation of ancient artifact with weathering effects.",
      year: "2024",
      software: ["Blender"],
      polyCount: "20k",
      bgColor: "#78716C",
      previewColor: "#A8A29E",
      rotationSpeed: 0.01,
      defaultDistance: 5,
      minDistance: 3,
      maxDistance: 10,
      modelPath: "/models/model2.glb",
      modelFileName: "ancient_artifact.glb"
    }
  ];

  return (
    <section className="threeD-models-section" id="3d-models">
      <div className="section-header">
        <h2 className="section-title">3D Models</h2>
        <p className="section-subtitle">Interactive 3D Portfolio <br /> (view on Desktop for interaction)</p>
      </div>
      
      {isMobile ? (
        // Mobile version: Simple 2x4 grid of images
        <div className="mobile-models-grid-container">
          <div className="mobile-models-grid">
            {mobileModels.map((model) => (
              <div 
                key={model.id}
                className="mobile-model-image-item"
              >
                <img 
                  src={model.image} 
                  alt={model.title}
                  className="mobile-model-image"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
          
          <div className="mobile-models-note">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" style={{ marginRight: '10px' }}>
              <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" stroke="currentColor" strokeWidth="2"/>
              <path d="M12 8v4M12 16h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            <span>For the best 3D experience with interactive controls, please visit on a desktop computer.</span>
          </div>
        </div>
      ) : (
        // Desktop version (original)
        <div className="models-grid-container">
          <div className="models-grid">
            {desktopModels.map((model) => (
              <div 
                key={model.id}
                className="model-card"
                style={{ 
                  '--model-bg-color': model.bgColor,
                  '--model-preview-color': model.previewColor
                }}
              >
                <div className="model-card-inner">
                  <div className="model-preview">
                    <div style={{ 
                      width: '100%',
                      height: '100%',
                      background: `linear-gradient(135deg, ${model.bgColor}20 0%, ${model.bgColor}05 100%)`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: '16px 16px 0 0',
                      overflow: 'hidden'
                    }}>
                      {/* Placeholder for 3D model */}
                      <div style={{
                        width: '80%',
                        height: '80%',
                        background: `linear-gradient(45deg, ${model.bgColor}30, ${model.previewColor}30)`,
                        borderRadius: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        fontSize: '1.5rem',
                        fontWeight: '600'
                      }}>
                        3D Model
                      </div>
                    </div>
                    <div className="model-preview::after">
                      Drag to rotate • Scroll to zoom
                    </div>
                  </div>
                  
                  <div className="model-card-content">
                    <h3 className="model-title">{model.title}</h3>
                    <p className="model-description">{model.description}</p>
                    
                    <div className="model-meta">
                      <div className="software-tags">
                        {model.software.map((software, index) => (
                          <span 
                            key={index} 
                            className="software-tag"
                            style={{ 
                              backgroundColor: `${model.bgColor}15`,
                              color: model.bgColor,
                              borderColor: `${model.bgColor}30`
                            }}
                          >
                            {software}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
};

export default ThreeDModelsSection;
